<?php

require_once(__DIR__ . "/../../model/Aluno.php");
require_once(__DIR__ . "/../../controller/AlunoController.php");

//1 - receber o id do aluno
$id = isset($_GET['id']) ? $_GET['id'] : 0;

// 2 - Chamar o controller para excluir o aluno
$alunoCont = new AlunoController();
$erros = $alunoCont->excluir($id);

// 3 - Verficar se deu erro
 if (!$erros) {
         //Redireciona para a listagem
        //3.2 - Se não deu erro, redirecionar para a lista de alunos
        header("location: listar.php");
    } else{
        //Converte o array de erros para string
          //3.1 - Se deu erro, exibir o erro na própria página
        $msgErro = implode("<br>", $erros);
        
    }


  

