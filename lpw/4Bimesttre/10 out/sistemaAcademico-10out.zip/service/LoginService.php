<?php

require_once(__DIR__ . "/../model/Usuario.php");
require_once(__DIR__ . "/../util/config.php");

class LoginService
{

    public function validarLogin(?string $login, ?string $senha)
    {

        $erros = array();

        //Adicionar erros se $login e $senha não estão preenchidos

        if (! $login) {
            array_push($erros, "Informe o login do usuário!");
        }

        if (! $senha) {
            array_push($erros, "Informe a senha do usuário!");
        }

        return $erros;
    }

    public function salvarUsuarioSessao(Usuario $usuario) {
        $this->iniciarSessao();

        $_SESSION[SESSAO_USUARIO_ID] = $usuario->getId();
        $_SESSION[SESSAO_USUARIO_NOME] = $usuario->getNome();
    }

    public function apagarDadosSessao(){ 
        
        $this->iniciarSessao();

        //Removo os dados da sessão
        session_unset();

        //Elimina a sessão
        session_destroy();
    }

    public function getNomeUsuarioLogado(){

       if ($this->usuarioEstaLogado()) {
         return $_SESSION[SESSAO_USUARIO_NOME];
       }
       else {
         return "(Não autenticado)";
       }

        if (isset($_SESSION[SESSAO_USUARIO_NOME])) {
            return $_SESSION[SESSAO_USUARIO_NOME];
        } else {
            return "(Não autenticado)";
        }
    }

     public function usuarioEstaLogado () {
        $this->iniciarSessao();

         if (isset($_SESSION[SESSAO_USUARIO_ID])) {
            return true;
        } else {
            return false;
        }

            
    }

    private function iniciarSessao()
    {
        //Habilita o recurso de sessão do PHP apenas se
        //não foi previamente habilitado
        if (session_status() != PHP_SESSION_ACTIVE)
            session_start();
    }
}
