const tela = document.querySelector("jogo-canvas");
const canvas = document.createElement("canvas");
let contexto;

let jogador = {};
let padraoObstaculo = {}; 
let vetorObstaculos = []; 
let pontuacao = 0;
let velocidadeMundo = 5; 
const gravidade = 0.8;
let forcaPulo = 15;
let jogoIniciado = false;
let intervaloDificuldade;

let ultimoCriado = 0;
const intervaloCriacao = 1500;

function iniciarJogo() {
    if (!tela) return;

    canvas.width = parseInt(tela.getAttribute("largura")) || 1000;
    canvas.height = parseInt(tela.getAttribute("altura")) || 400;
    contexto = canvas.getContext("2d");
    tela.appendChild(canvas);

    const elementoJogador = document.querySelector("jogador");
    if (elementoJogador) {
        jogador.tamanho = parseInt(elementoJogador.getAttribute("tamanho")) || 30;
        jogador.cor = elementoJogador.getAttribute("cor") || "verde";
        jogador.x = parseInt(elementoJogador.getAttribute("x")) || 50;
        jogador.yChao = canvas.height - jogador.tamanho;
        jogador.y = jogador.yChao;
        jogador.dy = 0;
    } else {
        return;
    }

    const elementoObstaculo = document.querySelector("obstaculo");
    if (elementoObstaculo) {
        padraoObstaculo.tamanho = parseInt(elementoObstaculo.getAttribute("tamanho")) || 40;
        padraoObstaculo.cor = elementoObstaculo.getAttribute("cor") || "vermelho";
    } else {
        padraoObstaculo.tamanho = 40;
        padraoObstaculo.cor = "vermelho";
    }
    
    document.addEventListener("keydown", function(event) {
        if ((event.key === " " || event.key === "ArrowUp") && jogador.y === jogador.yChao) {
            iniciarOuPular();
        }
    });

    animar();
}

function iniciarOuPular() {
    if (!jogoIniciado) {
        jogoIniciado = true;
        intervaloDificuldade = setInterval(aumentarDificuldade, 5000);
    }
    if (jogador.y === jogador.yChao) {
        jogador.dy = -forcaPulo;
    }
}

function desenharTudo() { 
    contexto.fillStyle = jogador.cor;
    contexto.fillRect(jogador.x, jogador.y, jogador.tamanho, jogador.tamanho);

    for (let i = 0; i < vetorObstaculos.length; i++) {
        const obs = vetorObstaculos[i];
        contexto.fillStyle = obs.cor;
        contexto.beginPath();
        contexto.moveTo(obs.x, obs.y + obs.tamanho);
        contexto.lineTo(obs.x + obs.tamanho / 2, obs.y);
        contexto.lineTo(obs.x + obs.tamanho, obs.y + obs.tamanho);
        contexto.closePath();
        contexto.fill();
    }
    
    contexto.fillStyle = "preto";
    contexto.font = "24px Arial";
    contexto.fillText(`Pontos: ${pontuacao.toFixed(0)}`, canvas.width - 150, 30);
}

function aumentarDificuldade() {
    velocidadeMundo += 1;
    forcaPulo += 0.5;
}

function reiniciarJogo() {
    alert(`Fim de Jogo! Pontuação: ${pontuacao.toFixed(0)}`);
    
    jogador.y = jogador.yChao;
    jogador.dy = 0;
    vetorObstaculos = [];
    pontuacao = 0;
    velocidadeMundo = 5;
    forcaPulo = 15;
    jogoIniciado = false;
    
    clearInterval(intervaloDificuldade);
}

function animar() {
    contexto.clearRect(0, 0, canvas.width, canvas.height);

    if (jogoIniciado) {
        jogador.dy += gravidade;
        jogador.y += jogador.dy;
        if (jogador.y >= jogador.yChao) { 
            jogador.y = jogador.yChao;
            jogador.dy = 0;
        }

        for (let i = 0; i < vetorObstaculos.length; i++) {
            vetorObstaculos[i].x -= velocidadeMundo; 
        }
        vetorObstaculos = vetorObstaculos.filter(obs => obs.x + obs.tamanho > 0);
        
        const agora = performance.now();
        if (agora - ultimoCriado > intervaloCriacao) {
            const tamanhoObs = padraoObstaculo.tamanho; 
            const corObs = padraoObstaculo.cor; 
            
            vetorObstaculos.push({
                x: canvas.width,
                y: canvas.height - tamanhoObs,
                tamanho: tamanhoObs,
                cor: corObs,
            });
            ultimoCriado = agora;
        }

        pontuacao += 0.1;
        
        for (let i = 0; i < vetorObstaculos.length; i++) {
            const obs = vetorObstaculos[i];
            
            if (
                jogador.x < obs.x + obs.tamanho &&
                jogador.x + jogador.tamanho > obs.x &&
                jogador.y < obs.y + obs.tamanho &&
                jogador.y + jogador.tamanho > obs.y
            ) {
                reiniciarJogo();
                break; 
            }
        }
    }
    
    desenharTudo();

    requestAnimationFrame(animar); 
}

window.onload = iniciarJogo;