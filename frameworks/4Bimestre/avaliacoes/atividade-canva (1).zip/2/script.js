const canvas = document.getElementById('Canvas');
const ctx = canvas.getContext('2d');

let retangulo = {
    x: 100,
    y: 100,
    width: 150,
    height: 100,
    dx: 2,
    dy: 4,
    color: 'pink'
}

function desenharRetangulo() {
    ctx.beginPath();
    ctx.rect(retangulo.x, retangulo.y, retangulo.width, retangulo.height);
    ctx.fillStyle = retangulo.color;
    ctx.fill();
    ctx.closePath();
}

function movimentoRetangulo() {
    retangulo.x += retangulo.dx;
    retangulo.y += retangulo.dy;        
    if (retangulo.x + retangulo.width > canvas.width || retangulo.x < 0) {  
        retangulo.dx = -retangulo.dx;
    }

    if (retangulo.y + retangulo.height > canvas.height || retangulo.y < 0) {  
        retangulo.dy = -retangulo.dy;
    }
}

function animar() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    desenharRetangulo();
    movimentoRetangulo();
    requestAnimationFrame(animar);
}

animar();