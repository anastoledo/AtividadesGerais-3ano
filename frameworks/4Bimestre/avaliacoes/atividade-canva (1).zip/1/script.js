const canvas = document.getElementById('Canvas');
const ctx = canvas.getContext('2d');

//CIRCULO
ctx.beginPath();
ctx.arc(150, 100, 50, 0, Math.PI * 2, false); 
ctx.fillStyle = 'purple'; 
ctx.fill();
ctx.strokeStyle = 'black'; 
ctx.closePath();

//RETANGULO
ctx.beginPath();
ctx.rect(50, 200, 200, 100);
ctx.fillStyle = 'pink'; 
ctx.fill();
ctx.strokeStyle = 'black'; 
ctx.stroke();
ctx.closePath();

//LINHA
ctx.beginPath();
ctx.moveTo(300, 50);
ctx.lineTo(450, 150);
ctx.strokeStyle = 'orange';
ctx.lineWidth = 5;
ctx.stroke();
ctx.closePath();