const canvas = document.getElementById('Canvas');
const ctx = canvas.getContext('2d');

let arrastando = false;

let inicio = { 
    x: 0, 
    y: 0 
}

let mouse = { 
    x: 0, 
    y: 0 
}

const centro = {
    x: canvas.width / 2,
    y: canvas.height / 2
}

function pegarPosicao(evento) {
    const limites = canvas.getBoundingClientRect();
    return {
        x: evento.clientX - limites.left,
        y: evento.clientY - limites.top
    }
}

canvas.addEventListener('mousedown', (evento) => {
    inicio = pegarPosicao(evento);
    arrastando = true;
})


canvas.addEventListener('mousemove', (evento) => {
    if (!arrastando){
        return;
    }
   
    mouse = pegarPosicao(evento);

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.beginPath();
    ctx.moveTo(centro.x, centro.y);
    ctx.lineTo(mouse.x, mouse.y);
    ctx.strokeStyle = 'blue';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.closePath();

    const largura = mouse.x - inicio.x;
    const altura = mouse.y - inicio.y;

    ctx.beginPath();
    ctx.rect(inicio.x, inicio.y, largura, altura);
    ctx.strokeStyle = 'red';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.closePath();
})

canvas.addEventListener('mouseup', () => {
    arrastando = false;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
})
