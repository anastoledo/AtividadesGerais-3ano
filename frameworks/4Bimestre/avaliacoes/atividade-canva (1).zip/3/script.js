const canvas = document.getElementById('Canvas');
const ctx = canvas.getContext('2d');


let circulo = {
    x: canvas.width / 2,
    y: canvas.height / 2,
    radius: 20,
    dx: 5, 
    dy: 7, 
    color: 'purple',
    velocidade: 5   
}

function desenharCirculo() {
    ctx.beginPath();
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.arc(circulo.x, circulo.y, circulo.radius, 0, Math.PI * 2);
    ctx.fillStyle = circulo.color;
    ctx.fill();
    ctx.closePath();
}

function movimentoCirculo(event) {
    const key = event.key;
    if (key === 'ArrowRight' && circulo.x + circulo.radius < canvas.width) {
        circulo.x += circulo.velocidade;
    }
    else if (key === 'ArrowLeft' && circulo.x - circulo.radius > 0) {
        circulo.x -= circulo.velocidade;
    }
    else if (key === 'ArrowUp' && circulo.y - circulo.radius > 0) {
        circulo.y -= circulo.velocidade;
    }
    else if (key === 'ArrowDown' && circulo.y + circulo.radius < canvas.height) {
        circulo.y += circulo.velocidade;
    }

    desenharCirculo();
}

document.addEventListener('keydown', movimentoCirculo);
desenharCirculo();

