const tela = document.getElementsByTagName("tela");

const canvas = document.createElement("canvas");
canvas.width = 1200;
canvas.height = 700;
const ctx = canvas.getContext("2d");
tela[0].appendChild(canvas);

//os campos de cada tipo
const tipo = document.getElementById("tipo");
const campoRaio = document.getElementById("campoRaio");
const campoLados = document.getElementById("campoLados");
const campoTamanho = document.getElementById("campoTamanho");

tipo.addEventListener("change", () => {
  campoRaio.style.display = (tipo.value === "arco" || tipo.value === "poligono") ? "block" : "none";
  campoLados.style.display = (tipo.value === "poligono") ? "block" : "none";
  campoTamanho.style.display = (tipo.value === "retangulo") ? "block" : "none";
});

//botao
document.getElementById("btnDesenhar").addEventListener("click", () => {
  const tipoForma = tipo.value;

  if (tipoForma === "arco") {
    desenhaArco();
  } else if (tipoForma === "retangulo") {
    desenhaRetangulo();
  } else if (tipoForma === "poligono") {
    desenhaPoligono();
  }
});


// desenha um arco (círculo)
function desenhaArco() {
  const x = Number(document.getElementById("x").value);
  const y = Number(document.getElementById("y").value);
  const raio = Number(document.getElementById("raio").value);
  const corMeio = document.getElementById("corMeio").value;
  const corBorda = document.getElementById("corBorda").value;

  ctx.beginPath();
  ctx.arc(x, y, raio, 0, Math.PI * 2);
  ctx.fillStyle = corMeio;
  ctx.fill();
  ctx.strokeStyle = corBorda;
  ctx.stroke();
  ctx.closePath();
}

// desenha um retângulo
function desenhaRetangulo() {
  const x = Number(document.getElementById("x").value);
  const y = Number(document.getElementById("y").value);
  const largura = Number(document.getElementById("largura").value);
  const altura = Number(document.getElementById("altura").value);
  const corMeio = document.getElementById("corMeio").value;
  const corBorda = document.getElementById("corBorda").value;

  ctx.beginPath();
  ctx.rect(x, y, largura, altura);
  ctx.fillStyle = corMeio;
  ctx.fill();
  ctx.strokeStyle = corBorda;
  ctx.stroke();
  ctx.closePath();
}

// desenha um polígono
function desenhaPoligono() {
  const x = Number(document.getElementById("x").value);
  const y = Number(document.getElementById("y").value);
  const lados = Number(document.getElementById("lados").value);
  const raio = Number(document.getElementById("raio").value);
  const corMeio = document.getElementById("corMeio").value;
  const corBorda = document.getElementById("corBorda").value;

  ctx.beginPath();
  for (let i = 0; i <= lados; i++) {
    const angulo = (i * 2 * Math.PI) / lados;
    const px = x + raio * Math.cos(angulo);
    const py = y + raio * Math.sin(angulo);
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }

  ctx.fillStyle = corMeio;
  ctx.fill();
  ctx.strokeStyle = corBorda;
  ctx.stroke();
  ctx.closePath();
}
