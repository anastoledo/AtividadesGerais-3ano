const tela = document.getElementsByTagName("tela")[0];
const canvas = document.createElement("canvas");
tela.appendChild(canvas);

canvas.width = tela.getAttribute("largura");
canvas.height = tela.getAttribute("altura");
canvas.style = "border:1px solid black";
const ctx = canvas.getContext("2d");
desenhar();


/*for (let i = 0; i < document.getElementsByTagName("arco").length; i++) {
mas depois é preciso declarar no indice
    desenhaArco(arco[i]);
}*/

function desenhar() {

    ctx.clearRect(0, 0, canvas.width, canvas.height)

    for (const arco of document.getElementsByTagName("arco")) {
        let x = parseInt(arco.getAttribute("px"));
        let y = parseInt(arco.getAttribute("py"));
        let raio = arco.getAttribute("raio") || 20; 
        let corMeio = arco.getAttribute("corMeio") || "purple"; 
        let corBorda = arco.getAttribute("corBorda") || "black"; 
        let anguloInicial = parseFloat(arco.getAttribute("anguloInicial") || 0);
        let anguloFinal = parseFloat(arco.getAttribute("anguloFinal") || Math.PI * 2);
        let orientacao = arco.getAttribute("orientacao") === "true" ? true : false;

        ctx.beginPath();
        ctx.arc(x, y, raio, anguloInicial, anguloFinal, orientacao); 
        ctx.fillStyle = corMeio; 
        ctx.fill();
        ctx.strokeStyle = corBorda;
        ctx.stroke();
        ctx.closePath();

    }

    for (const ret of document.getElementsByTagName("retangulo")) {
        let x = parseInt(ret.getAttribute("px"));
        let y = parseInt(ret.getAttribute("py"));
        let largura = parseInt(ret.getAttribute("largura") || 60);
        let altura = parseInt(ret.getAttribute("altura") || 40);
        let corMeio = ret.getAttribute("corMeio") || "pink";
        let corBorda = ret.getAttribute("corBorda") || "black";

        ctx.beginPath();
        ctx.fillStyle = corMeio;
        ctx.strokeStyle = corBorda;
        ctx.fillRect(x, y, largura, altura);
        ctx.strokeRect(x, y, largura, altura);
        ctx.closePath();
    }

    for (const pol of document.getElementsByTagName("poligono")) {
        let x = parseInt(pol.getAttribute("px"));
        let y = parseInt(pol.getAttribute("py"));
        let lados = parseInt(pol.getAttribute("lados") || 3);
        let raio = parseInt(pol.getAttribute("raio") || 30);
        let corMeio = pol.getAttribute("corMeio") || "pink";
        let corBorda = pol.getAttribute("corBorda") || "black";

        ctx.beginPath();
        for (let i = 0; i <= lados; i++) {
            const ang = (i * 2 * Math.PI) / lados;
            const px = x + raio * Math.cos(ang);
            const py = y + raio * Math.sin(ang);
            if (i === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
        }

        ctx.fillStyle = corMeio;
        ctx.fill();
        ctx.strokeStyle = corBorda;
        ctx.stroke();
        ctx.closePath();
    }

}

function atualizar() {
    let velH = 5;
    let velV = 5;

    for (const arc of document.getElementsByTagName("arco")) {
        arcoH = arc.getAttribute("moverH")
        arcoV = arc.getAttribute("moverV")

        if (arcoH) {
            let n = parseInt(arc.getAttribute("px"))
            arcoH === "direita" ? n += velH : n -= velH;
            if (n > canvas.width) n = 0
            if (n < 0) n = canvas.width
            arc.setAttribute("px", n)
        }

        if (arcoV) {
            let n = parseInt(arc.getAttribute("py"))
            arcoV === "cima" ? n += velV : n -= velV;
            if (n > canvas.width) n = 0
            if (n < 0) n = canvas.width
            arc.setAttribute("py", n)
        }

    }

    for (const ret of document.getElementsByTagName("retangulo")) {
        retH = ret.getAttribute("moverH")
        retV = ret.getAttribute("moverV")

        if (retH) {
            let n = parseInt(ret.getAttribute("px"))
            retH === "direita" ? n += velH : n -= velH;
            if (n > canvas.width) n = 0
            if (n < 0) n = canvas.width
            ret.setAttribute("px", n)
        }
        
        if (retV) {
            let n = parseInt(ret.getAttribute("py"))
            retV === "cima" ? n += velV : n -= velV;
            if (n > canvas.width) n = 0
            if (n < 0) n = canvas.width
            ret.setAttribute("py", n)
        }

    }

    for (const pol of document.getElementsByTagName("poligono")) {
        polH = pol.getAttribute("moverH")
        polV = pol.getAttribute("moverV")

        if (polH) {
            let n = parseInt(pol.getAttribute("px"))
            polH === "direita" ? n += velH : n -= velH;
            if (n > canvas.width) n = 0
            if (n < 0) n = canvas.width
            pol.setAttribute("px", n)
        }

        if (polV) {
            let n = parseInt(pol.getAttribute("py"))
            polV === "cima" ? n += velV : n -= velV;
            if (n > canvas.width) n = 0
            if (n < 0) n = canvas.width
            pol.setAttribute("py", n)
        }

    }

}

function animar() {
    desenhar();
    atualizar();
    requestAnimationFrame(animar);
}

animar();
