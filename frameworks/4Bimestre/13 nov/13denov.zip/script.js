const tela = document.getElementsByTagName("tela")[0];
const canvas = document.createElement("canvas");
tela.appendChild(canvas);

canvas.width = tela.getAttribute("largura");
canvas.height = tela.getAttribute("altura");
canvas.style = "border:1px solid black";
const ctx = canvas.getContext("2d");
desenhar();


/*for (let i = 0; i < document.getElementsByTagName("arco").length; i++) {
mas depois é preciso declarar no indice
    desenhaArco(arco[i]);
}*/

function desenhar() {

    ctx.clearRect(0, 0, canvas.width, canvas.height)
    for (const arco of document.getElementsByTagName("arco")) {
        let x = parseInt(arco.getAttribute("px"));
        let y = parseInt(arco.getAttribute("py"));
        let raio = arco.getAttribute("raio") || 20; //caso nao tenha raio, o raio padrao sera 20
        let corMeio = arco.getAttribute("corMeio") || "purple"; //caso nao tenha cor, a cor padrao sera roxo
        let corBorda = arco.getAttribute("corBorda") || "black"; //caso nao tenha cor, a cor padrao sera preto
        let anguloInicial = parseFloat(arco.getAttribute("anguloInicial") || 0);
        let anguloFinal = parseFloat(arco.getAttribute("anguloFinal") || Math.PI * 2);
        let orientacao = arco.getAttribute("orientacao") === "true" ? true : false;

        ctx.beginPath();
        ctx.arc(x, y, raio, anguloInicial, anguloFinal, orientacao); //false cria no sentido antihorario e true no sentido horario
        ctx.fillStyle = corMeio; //cor do preenchimento
        ctx.fill();
        ctx.strokeStyle = corBorda; //cor da borda
        ctx.stroke();
        ctx.closePath();

    }
}

function atualizar() {
    let velH = 5;
    let velV = 5;

    for (const arc of document.getElementsByTagName("arco")) {
        arcoH = arc.getAttribute("moverH")
        arcoV = arc.getAttribute("moverV")

        if (arcoH) {
            let n = parseInt(arc.getAttribute("px"))
            arcoH === "direita" ? n += velH : n -= velH;
            if (n > canvas.width) n = 0
            if (n < 0) n = canvas.width
            arc.setAttribute("px", n)
        }

        if (arcoV) {
            let n = parseInt(arc.getAttribute("py"))
            arcoV === "cima" ? n += velV : n -= velV;
            if (n > canvas.width) n = 0
            if (n < 0) n = canvas.width
            arc.setAttribute("py", n)
        }

    }

    /*for (const arco of document.getElementsByTagName("arco")) {
        let movimentoH = arco.getAttribute("moverH");
        let movimentoV = arco.getAttribute("moverV");
        if (movimentoH) {

            let n = parseInt(arco.getAttribute("px"));

            if (movimentoH.valueOf() === "direita") {
                n += 6;
                if (n > canvas.width) n = 0;
                arco.setAttribute("px", n);
            }
            //se for para esquerda
            else {
                n -= 6;
                if (n < 0) n = canvas.width;
                arco.setAttribute("px", n);
            }

        }
        if (movimentoV) {

            let n = parseInt(arco.getAttribute("py"));
            
            if (movimentoV.valueOf() === "cima") {
                n += 6;
                if (n > canvas.height) n = 0;
                arco.setAttribute("py", n);
            }

            else {
                n -= 6;
                if (n < 0) n = canvas.height;
                arco.setAttribute("py", n);
            }

        }
    }*/
}

function animar() {
    desenhar();
    atualizar();
    requestAnimationFrame(animar);
}

animar();
