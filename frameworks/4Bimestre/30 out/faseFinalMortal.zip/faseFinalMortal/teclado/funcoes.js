const canvas = document.getElementById('Canvas');
const ctx = canvas.getContext('2d');

//CONFIGURAÇÕES DO QUADRADO
let square = {
    x: 200,
    y: 200,
    size: 50,
    color: 'purple',
    speed: 15 //velocidade de movimento
};

//FUNÇÃO PARA DESENHAR O QUADRADO
function drawSquare() {
    ctx.beginPath();
    ctx.clearRect(0, 0, canvas.width, canvas.height); //limpa o canvas
    ctx.fillStyle = square.color;
    ctx.fillRect(square.x, square.y, square.size, square.size); //desenha o quadrado
    ctx.closePath();
};

//FUNÇÃO PARA MOVER O QUADRADO
function moveSquare(event) {
    const key = event.key;

    if (key === 'ArrowUp' && square.y > 0) {
        square.y -= square.speed; //move para cima
    } else if (key === 'ArrowDown' && square.y + square.size < canvas.height) {
        square.y += square.speed; //move para baixo
    } else if (key === 'ArrowLeft' && square.x > 0) {
        square.x -= square.speed; //move para esquerda
    } else if (key === 'ArrowRight' && square.x + square.size < canvas.width) {
        square.x += square.speed; //move para direita
    }

    drawSquare(); //redesenha o quadrado na nova posição

}
window.addEventListener('keydown', moveSquare);
//DESENHA O QUADRADO INICIALMENTE
drawSquare();

//obs: o plano cartesiano é invertido no eixo y no canvas em relação ao plano cartesiano tradicional.
//ou seja y para cima diminui o valor de y e y para baixo aumenta o valor de y.