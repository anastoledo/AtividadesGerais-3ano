const canvas = document.getElementById('Canvas');
const ctx = canvas.getContext('2d');

//CONFIGURAÇÕES Do CIRCULO
let circle = {
    x: canvas.width / 2,
    y: canvas.height / 2,
    radius: 20,
    color: 'purple',
    speed: 8,
    targetX: canvas.width / 2,
    targetY: canvas.height / 2,
};

//FUNÇÃO PARA DESENHAR O CIRCULO
function drawCircle() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.beginPath();
    ctx.arc(circle.x, circle.y, circle.radius, 0, Math.PI * 2);
    ctx.fillStyle = circle.color;
    ctx.fill();
    ctx.closePath();
};

//FUNÇÃO PARA ATUALIZAR A POSIÇÃO DO CIRCULO
function update() {
    const dx = circle.targetX - circle.x;
    const dy = circle.targetY - circle.y;
    const distance = Math.sqrt(dx * dx + dy * dy);

    if (distance > circle.speed) {
        circle.x += (dx / distance) * circle.speed;
        circle.y += (dy / distance) * circle.speed;
    } else {
        circle.x = circle.targetX;
        circle.y = circle.targetY;
    }

    drawCircle();
    requestAnimationFrame(update);
}

//EVENTO DE CLIQUE DO MOUSE
canvas.addEventListener('click', function(event) {
    const rect = canvas.getBoundingClientRect();
    circle.targetX = event.clientX - rect.left;
    circle.targetY = event.clientY - rect.top;
});

//INICIAR A ANIMAÇÃO
update();