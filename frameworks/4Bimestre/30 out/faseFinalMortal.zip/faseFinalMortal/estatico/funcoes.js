const canvas = document.getElementById('Canvas');
const ctx = canvas.getContext('2d');

//CIRCULO
ctx.beginPath();
ctx.arc(150, 100, 50, 0, Math.PI * 2, false); //PRIMEIRO É LARGURA, SEGUNDO É ALTURA, TERCEIRO É RAIO, QUARTO É INICIO, QUINTO É FIM, SEXTO É SENTIDO HORARIO OU ANTIHORARIO
ctx.fillStyle = 'purple'; //COR DE PREENCHIMENTO
ctx.fill();
ctx.strokeStyle = 'black'; //COR BORDA
ctx.stroke();
ctx.closePath();

//RETANGULO
ctx.beginPath();
ctx.rect(50, 200, 200, 100);
ctx.fillStyle = 'pink'; //COR DE PREENCHIMENTO
ctx.fill();
ctx.strokeStyle = 'black'; //COR BORDA
ctx.stroke();
ctx.closePath();

//TRIANGULO 
ctx.beginPath();
ctx.moveTo(300, 300); //PRIMEIRO PONTO DA LINHA
ctx.lineTo(400, 300); //SEGUNDO PONTO DA LINHA
ctx.lineTo(350, 200); //TERCEIRO PONTO DA LINHA
ctx.closePath();
ctx.fillStyle = 'orange'; //COR DE PREENCHIMENTO
ctx.fill();
ctx.strokeStyle = 'black'; //COR BORDA
ctx.stroke();