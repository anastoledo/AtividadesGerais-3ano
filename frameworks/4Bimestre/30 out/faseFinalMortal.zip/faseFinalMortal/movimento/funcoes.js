const canvas = document.getElementById('Canvas');
const ctx = canvas.getContext('2d');

//CONFIGURAÇÕES DA BOLA
let bola = {
    x: canvas.width / 2,
    y: canvas.height / 2,
    radius: 20,
    dx: 5, //velocidade horizontal
    dy: 7, //velocidade vertical
    color: 'purple'
};

//FUNÇÃO PARA DESENHAR A BOLA
function desenhar() {
    ctx.beginPath();
    ctx.arc(bola.x, bola.y, bola.radius, 0, Math.PI * 2);
    ctx.fillStyle = bola.color;
    ctx.fill();
    ctx.closePath();
};

//FUNÇÃO PARA ATUALIZAR A POSIÇÃO DA BOLA
function atualizarPosicaoBola() {
    //atualiza a posição da bola
    bola.x += bola.dx;
    bola.y += bola.dy;

    //verifica colisão com as bordas horizontais
    if (bola.x + bola.radius > canvas.width || bola.x - bola.radius < 0) {
        bola.dx = -bola.dx; //inverte a direção horizontal
    }

    //verifica colisão com as bordas verticais
    if (bola.y + bola.radius > canvas.height || bola.y - bola.radius < 0) {
        bola.dy = -bola.dy; //inverte a direção vertical
    }

};

//FUNÇÃO PRINCIPAL DE ANIMAÇÃO
function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height); //limpa o canvas
    desenhar(); //desenha a bola
    atualizarPosicaoBola(); //atualiza a posição da bola
    requestAnimationFrame(animate); //chama a função novamente para o próximo frame
};

//INICIA A ANIMAÇÃO
animate();