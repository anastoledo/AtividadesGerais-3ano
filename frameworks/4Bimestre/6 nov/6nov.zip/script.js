const tela = document.getElementsByTagName("tela");

const canvas = document.createElement("canvas");
    canvas.width = 2000;
    canvas.height = 1600;
    const ctx = canvas.getContext("2d");
    tela[0].appendChild(canvas);

    for (const arco of document.getElementsByTagName("arco")) { //of é usado para pegar o valor direto do elemento, sem precisar do indice
        desenhaArco(arco);
    }

    /*for (let i = 0; i < document.getElementsByTagName("arco").length; i++) {
    mas depois é preciso declarar no indice
        desenhaArco(arco[i]);
    }*/

function desenhaArco(arco) {
        const x = arco.getAttribute("px");
        const y = arco.getAttribute("py");
        const raio = arco.getAttribute("raio") || 20; //caso nao tenha raio, o raio padrao sera 20
        const corMeio = arco.getAttribute("corMeio") || "purple"; //caso nao tenha cor, a cor padrao sera roxo
        const corBorda = arco.getAttribute("corBorda") || "black"; //caso nao tenha cor, a cor padrao sera preto
        const anguloInicial = arco.getAttribute("anguloInicial") || 0;
        const anguloFinal = arco.getAttribute("anguloFinal") || 2;
        const orientacao = arco.getAttribute("orientacao") === "true" ? true : false;

        ctx.beginPath();
        ctx.arc(x, y, raio, anguloInicial, Math.PI * anguloFinal, orientacao); //false cria no sentido antihorario e true no sentido horario
        ctx.fillStyle = corMeio; //cor do preenchimento
        ctx.fill();
        ctx.strokeStyle = corBorda; //cor da borda
        ctx.stroke();
        ctx.closePath();

}