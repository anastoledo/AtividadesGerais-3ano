

var ctxCabecalho;
var ctxLinks;
var txtConteudo;
var ctxRodape;
var ancora = true;

document.addEventListener('DOMContentLoaded', function() {
    // Garante que um radio button esteja selecionado por padrão
    if (!document.querySelector('input[name="estiloLinks"]:checked')) {
        document.querySelector('input[name="estiloLinks"]').checked = true;
    }
});

function configEstiloCabecalho() {
    bg = document.getElementById("corFundo").value;
    corFonte = document.getElementById("corFonte").value;
    tamFonte = document.getElementById("tamFonte").value;
    ctxCabecalho = "#cabecalho{\n background-color:" + bg + ";\n";
    ctxCabecalho += " color:" + corFonte + ";\n";
    ctxCabecalho += " font-size:" + tamFonte + "pt;\n}\n";
    return ctxCabecalho;
}

function configEstiloLinks() {
    corLink = document.getElementById("corLinks").value;
    const estiloElement = document.querySelector('input[name="estiloLinks"]:checked');
    if (!estiloElement) return "";
    
    estiloLinks = estiloElement.value;
    ctxLinks = "a{\n color:" + corLink + ";\n";
    let aux = estiloLinks == "0" ? "none" : "underline";
    ctxLinks += " text-decoration:" + aux + ";\n}\n";
    return ctxLinks;
}

function configHtmlLinks() {
    if (!ancora) return "";
    links = document.getElementsByName("links");
    href = document.getElementsByName("href");
    ctxLinks = "";
    for (let i = 0; i < links.length; i++) {
        vet = href[i].value.split("\\");
        ctxLinks += '<a href="' + vet[vet.length - 1] + '">' + links[i].value + '</a>';
    }
    return ctxLinks;
}

function configHTMLCabecalho() {
    let aux = document.querySelector("#textoCabecalho").value;
    ctxCabecalho = '<h1>' + aux + '</h1>';
    return ctxCabecalho;
}

function configHTMLConteudo() {
    txtConteudo = "";
    txtConteudo = document.querySelector("#txtConteudo").value;
    img = document.getElementById("imagem").value;
    img = img.split("\\");
    txtConteudo += "<img src='" + img.pop() + "'>";
    return txtConteudo;
}

function configEstiloConteudo() {
    let alturaImg = document.getElementById("altura").value;
    let larguraImg = document.getElementById("largura").value;
    ctxConteudo = '#conteudo img{\n width:' + larguraImg + 'px;\nheight:' + alturaImg + 'px;\n}\n';
    return ctxConteudo;
}

function gerarCodigo() {
    // Código para CSS
    let codeCSS = document.querySelector("#codeCSS");
    let css = configEstiloCabecalho();
    if (ancora) {
        css += configEstiloLinks();
    }
    css += configEstiloConteudo();
    codeCSS.value = css;

    // Código para HTML
    let codeHTML = document.querySelector("#codeHTML");
    ctxHTML = "";
    ctxHTML = "<html>\n<meta-charset='utf-8'></meta-charset>\n<head>\n" +
        "<link rel='stylesheet' href='estilo.css'>\n" +
        "<title>Minha página</title>\n" +
        "</head>\n<body>" +
        "<div id='cabecalho'>" + configHTMLCabecalho() + "</div>\n";
    if (ancora) {
        const linksHTML = configHtmlLinks();
        if (linksHTML.trim() !== "") {
            ctxHTML += "<nav id='links'>\n" + linksHTML + "\n</nav>\n";
        }
    }
    ctxHTML += "<div id='conteudo'>\n" + configHTMLConteudo() + "\n</div>\n" +
        "</body>\n</html>";
    codeHTML.value = ctxHTML;
}

function download(campo, arquivo) {
    if (arquivo.trim() === '')
        arquivo = document.getElementById("nomeHTML").value + ".html";
    var text = document.getElementById(campo).value;
    var blob = new Blob([text], { type: "text/plain" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = arquivo.trim();
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

function criarLinks() {
    pai = document.getElementById("areaLinks");
    
    const container = document.createElement("div");
    container.className = "link-group";
    
    link = document.createElement("input");
    link.setAttribute("type", "text");
    link.setAttribute("name", "links");
    link.className = "input has-background-FAFDD6";
    link.setAttribute("placeholder", "nome do link");
    
    href = document.createElement("input");
    href.setAttribute("type", "file");
    href.setAttribute("name", "href");
    href.className = "input has-background-FAFDD6";
    href.onclick = aviso;
    
    bt = document.createElement("button");
    bt.setAttribute("type", "button");
    bt.className = "button has-background-FAFDD6";
    bt.innerText = "+";
    bt.onclick = criarLinks;
    
    btRemover = document.createElement("button");
    btRemover.setAttribute("type", "button");
    btRemover.className = "button has-background-FAFDD6";
    btRemover.innerText = "-";
    btRemover.onclick = function() { removerLinkUnico(this); };
    
    container.appendChild(link);
    container.appendChild(href);
    container.appendChild(bt);
    container.appendChild(btRemover);
    
    pai.appendChild(container);
}

function removerLinkUnico(botao) {
    botao.closest('.link-group').remove();
}

function removeLinks(check) {
    if (check.checked) {
        document.getElementById("areaLinks").style.display = "none";
        ancora = false;
    } else {
        document.getElementById("areaLinks").style.display = "block";
        ancora = true;
    }
}

function renderIframe() {
    const iframe = document.getElementById('pagina');
    const htmlCode = document.getElementById('codeHTML').value;
    const cssCode = document.getElementById('codeCSS').value;

    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlCode, 'text/html');

    const style = document.createElement('style');
    style.textContent = cssCode;

    if (doc.head) {
        doc.head.appendChild(style);
    }
    const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
    iframeDoc.open();
    iframeDoc.write('<!DOCTYPE html>\n' + doc.documentElement.outerHTML);
    iframeDoc.close();
}

function mostraOcultaDiv(id) {
    const divs = document.querySelectorAll('.content');
    divs.forEach(div => div.classList.remove('active'));
    document.getElementById(id).classList.add('active');
}

function aviso() {
    alert("Para que o link funcione o arquivo de destino deve estar no diretório do projeto");
    return true;
}