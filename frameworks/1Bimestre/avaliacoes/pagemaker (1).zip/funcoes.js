var ctxCabecalho;
var ctxLinks;
var ctxRodape;

function configEstiloCabecalho() {
    bg = document.getElementById("corFundo").value;
    corFonte = document.getElementById("corFonte").value;
    tamFonte = document.getElementById("tamFonte").value;
    largura = document.getElementById('larguraCabecalho').value || '100%';
    altura = document.getElementById('alturaCabecalho').value || 'auto';
    fonteCabecalho = document.getElementById('fonteCabecalho').value;

    ctxCabecalho = "#cabecalho{\n background-color:" + bg + ";\n";
    ctxCabecalho += " color:" + corFonte + ";\n";
    ctxCabecalho += " font-size:" + tamFonte + "pt;\n";
    ctxCabecalho += " font-family:" + fonteCabecalho + ";\n";
    ctxCabecalho += " width:" + largura + ";\n";
    ctxCabecalho += " height:" + altura + ";\n";
    ctxCabecalho += " padding: 10px;\n"; // adicionei pra melhor visualização
    ctxCabecalho += " box-sizing: border-box;\n}\n";

    return ctxCabecalho;
}

function configEstiloLinks() {
    corLink = document.getElementById("corLinks").value;
    estiloLinks = document.querySelector('input[name="estiloLinks"]:checked').value;
    largura = document.getElementById('larguraLinks').value || '100%';
    altura = document.getElementById('alturaLinks').value || 'auto';
    fonteLink = document.getElementById('fonteLink').value;

    ctxLinks = "#links {\n";
    ctxLinks += " width:" + largura + ";\n";
    ctxLinks += " height:" + altura + ";\n";
    ctxLinks += " padding: 10px;\n";
    ctxLinks += " box-sizing: border-box;\n}\n";

    ctxLinks = "a{\n color:" + corLink + ";\n";
    ctxLinks += " font-family:" + fonteLink + ";\n";
    let aux = estiloLinks == "0" ? "none" : "underline";
    ctxLinks += " text-decoration:" + aux + ";\n}\n";
    return ctxLinks;
}

function configEstiloRodape() {
    bgRodape = document.getElementById("corFundoRodape").value;
    fonteRodape = document.getElementById("fonteRodape").value;

    ctxRodape = "#rodape {\n";
    ctxRodape += "  background-color: " + bgRodape + ";\n";
    ctxRodape += "  padding: 20px;\n";
    ctxRodape += "  text-align: center;\n";
    ctxRodape += "  font-family: " + fonteRodape + " ;\n}\n";
    return ctxRodape;
}

function configHTMLRodape() {
    let textoRodape = document.getElementById("textoRodape").value;
    return '<footer id="rodape">' + textoRodape + '</footer>';
}

function configEstiloConteudo(){
    let ctxConteudo = "";
    corConteudo = document.getElementById("corConteudo").value;
    largura = document.getElementById('larguraConteudo').value || '100%';
    altura = document.getElementById('alturaConteudo').value || 'auto';
    fonteConteudo = document.getElementById('fonteConteudo').value;

    ctxConteudo = "#conteudo {\n";
    ctxConteudo += "  background-color: " + corConteudo + ";\n";
    ctxConteudo += "  width:" + largura + ";\n";
    ctxConteudo += "  height:" + altura + ";\n";
    ctxConteudo += "  padding: 15px;\n";
    ctxConteudo += "  box-sizing: border-box;\n";
    ctxConteudo += "  font-family:" + fonteConteudo + ";\n}\n";
    return ctxConteudo;

}

function configHTMLConteudo() {
    let conteudoHTML = "";
    
    // Adiciona parágrafos
    let textoParagrafo = document.getElementById('textoConteudo').value;
    if (textoParagrafo.trim()) {
        conteudoHTML += `<p>${textoParagrafo}</p>\n`;
    }
    
    // Adiciona imagens
    let legendaImagem = document.getElementById('legendaImagem').value;
    let arquivoImagem = document.getElementById('arquivoImagem').value;
    if (arquivoImagem) {
        arquivoImagem = arquivoImagem.split('\\').pop();
        conteudoHTML += `<figure>
            <img src="${arquivoImagem}" alt="${legendaImagem}">
            <figcaption>${legendaImagem}</figcaption>
        </figure>\n`;
    }
    
    return conteudoHTML;
    
}

function configHtmlLinks() {
    let links = document.getElementsByName("links");
    let hrefs = document.getElementsByName("href");
    let htmlLinks = "";
   
    for (let i = 0; i < links.length; i++) {
        if (links[i].value && hrefs[i].value) {
            let href = hrefs[i].value.split("\\");
            htmlLinks += '<a href="' + href[href.length - 1] + '">' + links[i].value + '</a>\n';
        }
    }
    return htmlLinks;
}

function configHTMLCabecalho() {
    let aux = document.querySelector("#textoCabecalho").value;
    return '<h1>' + aux + '</h1>';
}

function gerarInput() {
    links = document.getElementsByName("links");
    href = document.getElementsByName("href");
}

function gerarCodigo() {
    // Código para CSS
    let codeCSS = document.querySelector("#codeCSS");
    let css = configEstiloCabecalho();
    css += configEstiloLinks();
    css += configEstiloConteudo();
    css += configEstiloRodape();
    codeCSS.value = css;

    // Código para HTML
    let codeHTML = document.querySelector("#codeHTML");
    ctxHTML = "<html>\n<head>\n" +
        "<link rel='stylesheet' href='estilo.css'>\n" +
        "<title>Minha página</title>\n" +
        "</head>\n<body>" +
        "<div id='cabecalho'>" + configHTMLCabecalho() + "</div>\n" +
        "<nav id='links'>\n" + configHtmlLinks() + "</nav>\n" +
        "<div id='conteudo'>\n" + configHTMLConteudo() + "</div>\n" +
        configHTMLRodape() + "\n" +
        "</body>\n</html>";
 
    codeHTML.value = ctxHTML;
}

function download(campo, arquivo) {
    if (arquivo.trim() === '')
        arquivo = document.getElementById("nomeHTML").value + ".html";
    var text = document.getElementById(campo).value;
    var blob = new Blob([text], { type: "text/plain" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = arquivo.trim();
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}