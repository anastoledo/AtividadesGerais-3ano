<html>
    <head>
        <title>Cadastro de cursos</title>
    </head>
    <body>
        <form>
            <label for='campo_id'>id</label>
<input type='text' name='campo_id'><br>
<label for='campo_nome'>nome</label>
<input type='text' name='campo_nome'><br>
<label for='campo_turno'>turno</label>
<input type='text' name='campo_turno'><br>

        </form>
    </body>
</html>