<html>
    <head>
        <title>Lista de Cursos</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
        <h1>Lista de Cursos</h1>
        <?php
        require_once("../dao/CursosDao.php");
        $dao = new CursosDao();
        $dados = $dao->listaGeral();
        ?>
        <table border="1">
            <thead>
                <tr>
                    <th>id</th><th>nome</th><th>turno</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($dados as $dado): ?>
                <tr>
                        <td><?php echo $dado['id']; ?></td>
    <td><?php echo $dado['nome']; ?></td>
    <td><?php echo $dado['turno']; ?></td>

                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </body>
</html>