<html>
    <head>
        <title>Lista de Alunos</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
        <h1>Lista de Alunos</h1>
        <?php
        require_once("../dao/AlunosDao.php");
        $dao = new AlunosDao();
        $dados = $dao->listaGeral();
        ?>
        <table border="1">
            <thead>
                <tr>
                    <th>id</th><th>nome</th><th>idade</th><th>estrangeiro</th><th>id_curso</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($dados as $dado): ?>
                <tr>
                        <td><?php echo $dado['id']; ?></td>
    <td><?php echo $dado['nome']; ?></td>
    <td><?php echo $dado['idade']; ?></td>
    <td><?php echo $dado['estrangeiro']; ?></td>
    <td><?php echo $dado['id_curso']; ?></td>

                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </body>
</html>