<?php  

$mensagens = [
    'Erro 0: Não foi possível criar diretórios',
    'Erro 1: Falha ao conectar ao banco de dados',
    'Projeto criado: faça download clicando <a href=sistema.zip>aqui</a>',
    'Erro 3: Não foi possível obter as tabelas',
    'Erro 4: Não foi possível gerar os Models',
    'Erro 5: Não foi possível gerar a conexão',
    'Erro 6: Não foi possível gerar os Controllers',
    'Erro 7: Não foi possível gerar os arquivos View',
    'Erro 8: Não foi possível gerar o CSS',
    'Erro 9: Falha ao compactar o projeto'
];
