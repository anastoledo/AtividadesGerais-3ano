<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

class Creator {
    private $con;
    private $servidor;
    private $banco;
    private $usuario;
    private $senha;
    private $tabelas;

    function __construct() {
        if (!$this->criaDiretorios()) header("Location:index.php?msg=0");
        if (!$this->conectar()) header("Location:index.php?msg=1");
        if (!$this->buscaTabelas()) header("Location:index.php?msg=3");
        if (!$this->ClassesModel()) header("Location:index.php?msg=4");
        if (!$this->ClasseConexao()) header("Location:index.php?msg=5");
        if (!$this->ClassesControl()) header("Location:index.php?msg=6");
        if (!$this->classesView()) header("Location:index.php?msg=7");
        if (!$this->criarCSS()) header("Location:index.php?msg=8");
        if (!$this->compactar()) header("Location:index.php?msg=9");

        header("Location:index.php?msg=2");
    }

    function criaDiretorios() {
        try {
            $dirs = [
                "sistema",
                "sistema/model",
                "sistema/control",
                "sistema/view",
                "sistema/dao",
                "sistema/css"
            ];

            foreach ($dirs as $dir) {
                if (!file_exists($dir)) {
                    if (!mkdir($dir, 0777, true)) return false;
                }
            }
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    function conectar() {
        $this->servidor = $_POST["servidor"];
        $this->banco = $_POST["banco"];
        $this->usuario = $_POST["usuario"];
        $this->senha = $_POST["senha"];
        try {
            $this->con = new PDO(
                "mysql:host=" . $this->servidor . ";dbname=" . $this->banco,
                $this->usuario,
                $this->senha
            );
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    function buscaTabelas() {
        try {
            $sql = "SHOW TABLES";
            $query = $this->con->query($sql);
            $this->tabelas = $query->fetchAll(PDO::FETCH_ASSOC);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    function buscaAtributos($nomeTabela) {
        $sql = "SHOW COLUMNS FROM " . $nomeTabela;
        return $this->con->query($sql)->fetchAll(PDO::FETCH_OBJ);
    }

    function ClassesModel() {
        try {
            foreach ($this->tabelas as $tabela) {
                $nomeTabela = array_values((array)$tabela)[0];
                $atributos = $this->buscaAtributos($nomeTabela);
                $nomeAtributos = "";
                $geters_seters = "";
                foreach ($atributos as $atributo) {
                    $atributo = $atributo->Field;
                    $nomeAtributos .= "\tprivate \${$atributo};\n";
                    $metodo = ucfirst($atributo);
                    $geters_seters .= "\tfunction get{$metodo}() { return \$this->{$atributo}; }\n";
                    $geters_seters .= "\tfunction set{$metodo}(\${$atributo}) { \$this->{$atributo} = \${$atributo}; }\n";
                }
                $nomeTabela = ucfirst($nomeTabela);
                $conteudo = <<<EOT
<?php
class {$nomeTabela} {
{$nomeAtributos}
{$geters_seters}
}
?>
EOT;
                file_put_contents("sistema/model/{$nomeTabela}.php", $conteudo);
            }
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    function classesView() {
        try {
            foreach ($this->tabelas as $tabela) {
                $nomeTabela = array_values((array)$tabela)[0];
                $atributos = $this->buscaAtributos($nomeTabela);
                $formCampos = "";

                foreach ($atributos as $atributo) {
                    if (strtolower($atributo->Key) === "pri") continue;

                    $tipoBanco = strtoupper($atributo->Type);
                    $tipoInput = "text";

                    if (str_contains($tipoBanco, 'INT')) {
                        $tipoInput = "number";
                    } elseif (str_contains($tipoBanco, 'DATE')) {
                        $tipoInput = "date";
                    }

                    $formCampos .= <<<HTML
<label for="campo_{$atributo->Field}">{$atributo->Field}</label>
<input type="{$tipoInput}" name="campo_{$atributo->Field}" id="campo_{$atributo->Field}"><br>
HTML;
                }

                $conteudo = <<<HTML
<html>
<head>
    <title>Cadastro de {$nomeTabela}</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
    <form>
        {$formCampos}
        <button type="submit">Enviar</button>
    </form>
</body>
</html>
HTML;
                file_put_contents("sistema/view/{$nomeTabela}.php", $conteudo);
            }
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    function ClasseConexao() {
        try {
            $conteudo = <<<EOT
<?php
class Conexao {
    private \$server;
    private \$banco;
    private \$usuario;
    private \$senha;
    function __construct() {
        \$this->server = '[Informe aqui o servidor]';
        \$this->banco = '[Informe aqui o seu Banco de dados]';
        \$this->usuario = '[Informe aqui o usuário do banco de dados]';
        \$this->senha = '[Informe aqui a senha do banco de dados]';
    }
    function conectar() {
        try {
            \$conn = new PDO("mysql:host=" . \$this->server . ";dbname=" . \$this->banco, \$this->usuario, \$this->senha);
            return \$conn;
        } catch (Exception \$e) {
            echo "Erro ao conectar com o Banco de dados: " . \$e->getMessage();
        }
    }
}
?>
EOT;
            file_put_contents("sistema/model/conexao.php", $conteudo);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    function ClassesControl() {
        try {
            foreach ($this->tabelas as $tabela) {
                $nomeTabela = array_values((array)$tabela)[0];
                $nomeClasse = ucfirst($nomeTabela);
                $conteudo = <<<EOT
<?php
require_once("../model/{$nomeClasse}.php");
require_once("../dao/{$nomeClasse}Dao.php");
class {$nomeClasse}Control {
    private \${$nomeTabela};
    private \$acao;
    private \$dao;
    public function __construct() {
        \$this->{$nomeTabela} = new {$nomeClasse}();
        \$this->dao = new {$nomeClasse}Dao();
        \$this->acao = \$_GET["a"];
        \$this->verificaAcao();
    }
    function verificaAcao() {}
    function inserir() {}
    function excluir() {}
    function alterar() {}
    function buscarId({$nomeClasse} \${$nomeTabela}) {}
    function buscaTodos() {}
}
new {$nomeClasse}Control();
?>
EOT;
                file_put_contents("sistema/control/{$nomeTabela}Control.php", $conteudo);
            }
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    function criarCSS() {
        try {
            $css = <<<EOT
body {
    font-family: Arial, sans-serif;
    background-color: #f5f5f5;
}
form {
    background-color: #fff;
    padding: 20px;
    margin: 20px auto;
    width: 400px;
    border-radius: 10px;
    box-shadow: 0 0 10px #ccc;
}
label {
    display: block;
    margin-top: 10px;
}
input, select, button {
    width: 100%;
    padding: 8px;
    margin-top: 5px;
    box-sizing: border-box;
}
button {
    margin-top: 15px;
    background-color: #4CAF50;
    color: white;
    border: none;
    cursor: pointer;
}
button:hover {
    background-color: #45a049;
}
EOT;
            file_put_contents("sistema/css/estilos.css", $css);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    function compactar() {
        try {
            $folderToZip = 'sistema';
            $outputZip = 'sistema.zip';
            $zip = new ZipArchive();
            if ($zip->open($outputZip, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
                return false;
            }
            $folderPath = realpath($folderToZip);
            if (!is_dir($folderPath)) return false;
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($folderPath),
                RecursiveIteratorIterator::LEAVES_ONLY
            );
            foreach ($files as $file) {
                if (!$file->isDir()) {
                    $filePath = $file->getRealPath();
                    $relativePath = substr($filePath, strlen($folderPath) + 1);
                    $zip->addFile($filePath, $relativePath);
                }
            }
            return $zip->close();
        } catch (Exception $e) {
            return false;
        }
    }
}

new Creator();
