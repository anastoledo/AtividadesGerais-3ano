<?php
$servidor = $_POST['servidor'] ?? '';
$usuario = $_POST['usuario'] ?? '';
$senha = $_POST['senha'] ?? '';
$bancos = array();

if ($servidor && $usuario) {
    try {
        $pdo = new PDO("mysql:host=$servidor", $usuario, $senha);
        $sql = "SHOW DATABASES";
        $query = $pdo->query($sql);
        $bancos = $query->fetchAll(PDO::FETCH_COLUMN);
    } 
    catch (Exception $e) {
        header("Location:index.php?msg=1");
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Formulário cadastro</title>
<link rel="stylesheet" href="estilos.css">
</head>
<body>
<div class="container">
    <form method="POST">
        <?php
        include 'mensagens.php';
        if (isset($_GET['msg']) ){
            $msg=$_GET['msg'];
            $classe=$msg==2?'mensagem':'mensagem_erro';
            echo "<div class=\"$classe\">"  . ($mensagens[$msg] ?? "Erro desconhecido") . "</div>";
        }
?>

    <h1>EasyMVC</h1>
    <h2>Configuração</h2>

    <label>Servidor:</label>
    <input type="text" name="servidor" id="servidor" value="<?= $servidor ?>" required><br>

    <label>Usuário:</label>
    <input type="text" id="usuario" name="usuario" value="<?= $usuario ?>" required><br>

    <label>Senha:</label>
    <input type="password" id="senha" name="senha" value="<?= $senha ?>" required><br>

    <?php
    if ($bancos) { ?>
    <label for="banco">Banco de dados:</label>
    <select name="banco" id="banco" required>
        <?php
        foreach ($bancos as $banco) {
        ?>
            <option value="<?= $banco ?>"><?= $banco ?></option>
            <?php
        }
        ?>
    </select>
    <br>
    <button type="submit" formaction="creator.php">Criar Projeto</button>
    <?php
} else {
    ?>
    <button type="submit">Conectar e listar bancos</button>
    <?php
}
?>

</form>
</div>   
</body>