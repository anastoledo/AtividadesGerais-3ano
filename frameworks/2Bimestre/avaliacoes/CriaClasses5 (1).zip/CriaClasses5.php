<?php 
include "Conexao.php";

class CriaClasses1 {
    private $con;

    function __construct() {
        $this->con = (new Conexao())->conectar();
    }

    function ClassesModel() {
        if (!file_exists("sistema")) {
            mkdir("sistema");
        }

        if (!file_exists("sistema/model")) {
            mkdir("sistema/model");
        }

        $sql = "SHOW TABLES";
        $query = $this->con->query($sql);
        $tabelas = $query->fetchAll(PDO::FETCH_ASSOC);

        foreach ($tabelas as $tabela) {
            $nomeTabela = array_values($tabela)[0];
            $sql = "SHOW COLUMNS FROM " . $nomeTabela;
            $atributos = $this->con->query($sql)->fetchAll(PDO::FETCH_OBJ);

            $nomeAtributos = "";
            $metodos = "";

            foreach ($atributos as $atributo) {
                $campo = $atributo->Field;
                $nomeMetodo = ucfirst($campo);

                // Atributo privado
                $nomeAtributos .= "    private \${$campo};\n";

                // Get
                $metodos .= <<<GET

    public function get{$nomeMetodo}() {
        return \$this->{$campo};
    }

GET;

                // Set
                $metodos .= <<<SET

    public function set{$nomeMetodo}(\${$campo}): self {
        \$this->{$campo} = \${$campo};
        return \$this;
    }

SET;
            }

            $nomeClasse = ucfirst($nomeTabela);
            $conteudo = <<<EOT
<?php
class {$nomeClasse} {
{$nomeAtributos}
{$metodos}
}
?>
EOT;

            file_put_contents("sistema/model/{$nomeClasse}.php", $conteudo);
            echo "Classe {$nomeClasse} criada com sucesso!\n";
        }
    }
}

(new CriaClasses1())->ClassesModel();
